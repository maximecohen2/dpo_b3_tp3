﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBuilderCSHARP
{
    public class CarEspaceBuilder : CarBuilder
    {


        public override void BuildChassis()
        {
            car.SetChassis("long");
        }

        public override void BuildBodyWork()
        {
            car.SetBodyWork("5-door");
        }

        public override void BuildEngine()
        {
            car.SetEngine("diesel");
        }

    }
}
