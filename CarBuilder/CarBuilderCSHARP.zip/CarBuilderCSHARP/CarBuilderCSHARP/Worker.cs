﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBuilderCSHARP
{
    public class Worker
    {

            private CarBuilder carBuilder;

            public void SetCarBuilder(CarBuilder pb)
            {
                carBuilder = pb;
            }

            public Car GetCar()
            {
                return carBuilder.GetCar();
            }

            public void ConstructCar()
            {
                carBuilder.CreateNewCar();
                carBuilder.BuildChassis();
                carBuilder.BuildBodyWork();
                carBuilder.BuildEngine();
            }
        }

    
}
