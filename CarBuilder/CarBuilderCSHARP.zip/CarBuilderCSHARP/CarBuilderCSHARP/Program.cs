﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarBuilderCSHARP
{
    static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());


                Worker worker = new Worker();
                CarBuilder carClioBuilder = new CarClioBuilder();
                CarBuilder carEspaceBuilder = new CarEspaceBuilder();

                worker.SetCarBuilder(carClioBuilder);
                worker.ConstructCar();

                Car car = worker.GetCar();
                Console.Write(car);

                worker.SetCarBuilder(carEspaceBuilder);
                worker.ConstructCar();

                car = worker.GetCar();
                Console.WriteLine(car);
        }
        }
    }
