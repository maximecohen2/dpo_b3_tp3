﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBuilderCSHARP
{
    public abstract class CarBuilder
    {

        protected Car car;

        public Car GetCar()
        {
            return car;
        }

        public void CreateNewCar()
        {
            car = new Car();
        }

        public abstract void BuildChassis();

        public abstract void BuildBodyWork();

        public abstract void BuildEngine();

    }
}
