﻿namespace CarBuilderCSHARP
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBoxClio = new System.Windows.Forms.TextBox();
            this.lblClio = new System.Windows.Forms.Label();
            this.lblEspace = new System.Windows.Forms.Label();
            this.txtBoxEspace = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtBoxClio
            // 
            this.txtBoxClio.Location = new System.Drawing.Point(445, 179);
            this.txtBoxClio.Name = "txtBoxClio";
            this.txtBoxClio.ReadOnly = true;
            this.txtBoxClio.Size = new System.Drawing.Size(318, 20);
            this.txtBoxClio.TabIndex = 0;
            this.txtBoxClio.TextChanged += new System.EventHandler(this.txtBoxClio_TextChanged);
            // 
            // lblClio
            // 
            this.lblClio.AutoSize = true;
            this.lblClio.Location = new System.Drawing.Point(354, 185);
            this.lblClio.Name = "lblClio";
            this.lblClio.Size = new System.Drawing.Size(24, 13);
            this.lblClio.TabIndex = 1;
            this.lblClio.Text = "Clio";
            // 
            // lblEspace
            // 
            this.lblEspace.AutoSize = true;
            this.lblEspace.Location = new System.Drawing.Point(354, 225);
            this.lblEspace.Name = "lblEspace";
            this.lblEspace.Size = new System.Drawing.Size(43, 13);
            this.lblEspace.TabIndex = 3;
            this.lblEspace.Text = "Espace";
            // 
            // txtBoxEspace
            // 
            this.txtBoxEspace.Location = new System.Drawing.Point(445, 219);
            this.txtBoxEspace.Name = "txtBoxEspace";
            this.txtBoxEspace.ReadOnly = true;
            this.txtBoxEspace.Size = new System.Drawing.Size(318, 20);
            this.txtBoxEspace.TabIndex = 2;
            this.txtBoxEspace.TextChanged += new System.EventHandler(this.txtBoxEspace_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblEspace);
            this.Controls.Add(this.txtBoxEspace);
            this.Controls.Add(this.lblClio);
            this.Controls.Add(this.txtBoxClio);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBoxClio;
        private System.Windows.Forms.Label lblClio;
        private System.Windows.Forms.Label lblEspace;
        private System.Windows.Forms.TextBox txtBoxEspace;
    }
}

