﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBuilderCSHARP
{
    public class Car
    {
        private String chassis = "";
        private String bodywork = "";
        private String engine = "";

        public void SetChassis(String chassis)
        {
            this.chassis = chassis;
        }

        public void SetBodyWork(String bodywork)
        {
            this.bodywork = bodywork;
        }

        public void SetEngine(String engine)
        {
            this.engine = engine;
        }

    }
}
