﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBuilderCSHARP
{
   public class CarClioBuilder : CarBuilder
    {


        public override void BuildChassis()
        {
           car.SetChassis("short");
        }

        public override void BuildBodyWork()
        {
            car.SetBodyWork("3-door");
        }

        public override void BuildEngine()
        {
            car.SetEngine("gasoline");
        }
    
}
}
